
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { CheckCircle, Award, Users, Clock, Target, Heart } from "lucide-react";

const teamMembers = [
  {
    name: "Александр Иванов",
    position: "CEO / Основатель",
    bio: "Более 15 лет опыта в IT-индустрии. Специализируется на стратегическом планировании и развитии бизнеса."
  },
  {
    name: "Екатерина Смирнова",
    position: "Арт-директор",
    bio: "Опытный дизайнер с портфолио международных проектов. Отвечает за визуальную идентичность и UX/UI дизайн."
  },
  {
    name: "Дмитрий Петров",
    position: "Технический директор",
    bio: "Эксперт в области веб-разработки и архитектуры приложений. Руководит техническими аспектами всех проектов."
  },
  {
    name: "Мария Козлова",
    position: "Менеджер проектов",
    bio: "Сертифицированный PMP с опытом управления сложными проектами. Обеспечивает своевременную доставку проектов."
  },
  {
    name: "Сергей Новиков",
    position: "Ведущий разработчик",
    bio: "Fullstack разработчик с глубокими знаниями современных технологий и фреймворков."
  },
  {
    name: "Анна Соколова",
    position: "Маркетолог",
    bio: "Специалист по цифровому маркетингу с опытом работы в крупных агентствах. Отвечает за продвижение и аналитику."
  }
];

const values = [
  {
    icon: <Target className="h-10 w-10 text-primary" />,
    title: "Ориентация на результат",
    description: "Мы фокусируемся на достижении измеримых результатов, которые помогают нашим клиентам достигать бизнес-целей."
  },
  {
    icon: <Users className="h-10 w-10 text-primary" />,
    title: "Командная работа",
    description: "Мы верим в силу коллективного разума и тесно сотрудничаем как внутри команды, так и с нашими клиентами."
  },
  {
    icon: <Clock className="h-10 w-10 text-primary" />,
    title: "Своевременность",
    description: "Мы ценим время наших клиентов и всегда стремимся доставлять проекты в срок или раньше."
  },
  {
    icon: <Award className="h-10 w-10 text-primary" />,
    title: "Качество",
    description: "Мы не идем на компромиссы в вопросах качества и всегда стремимся превзойти ожидания клиентов."
  },
  {
    icon: <Heart className="h-10 w-10 text-primary" />,
    title: "Страсть к инновациям",
    description: "Мы постоянно исследуем новые технологии и подходы, чтобы предлагать самые современные решения."
  }
];

const AboutPage = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-background relative overflow-hidden hero-pattern">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600 blob" style={{ animationDuration: "15s" }}></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-600 blob" style={{ animationDuration: "20s" }}></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1
              className="text-4xl md:text-5xl font-bold mb-6 gradient-text"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              О нашей компании
            </motion.h1>
            <motion.p
              className="text-xl text-muted-foreground mb-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Мы — команда профессионалов, объединенных страстью к созданию
              инновационных цифровых решений, которые помогают бизнесу расти.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-primary text-sm font-medium uppercase tracking-wider">
                Наша история
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-6">
                Как все начиналось
              </h2>
              <p className="text-muted-foreground text-lg mb-6">
                DigitalCraft была основана в 2015 году группой энтузиастов, объединенных общей целью — создавать цифровые продукты, которые не только выглядят привлекательно, но и решают реальные бизнес-задачи.
              </p>
              <p className="text-muted-foreground text-lg mb-6">
                Начав с небольших проектов, мы быстро завоевали доверие клиентов благодаря нашему профессионализму, креативному подходу и ориентации на результат. Сегодня мы гордимся тем, что работаем с компаниями разного масштаба — от стартапов до крупных корпораций.
              </p>
              <p className="text-muted-foreground text-lg mb-6">
                За годы работы мы реализовали более 200 проектов в различных отраслях, помогая нашим клиентам достигать новых высот в цифровом пространстве.
              </p>
              <div className="flex flex-wrap gap-4 mt-8">
                <div className="bg-secondary/30 rounded-lg p-4 text-center">
                  <span className="text-3xl font-bold gradient-text">7+</span>
                  <p className="text-sm text-muted-foreground mt-1">Лет опыта</p>
                </div>
                <div className="bg-secondary/30 rounded-lg p-4 text-center">
                  <span className="text-3xl font-bold gradient-text">200+</span>
                  <p className="text-sm text-muted-foreground mt-1">Проектов</p>
                </div>
                <div className="bg-secondary/30 rounded-lg p-4 text-center">
                  <span className="text-3xl font-bold gradient-text">50+</span>
                  <p className="text-sm text-muted-foreground mt-1">Клиентов</p>
                </div>
                <div className="bg-secondary/30 rounded-lg p-4 text-center">
                  <span className="text-3xl font-bold gradient-text">15+</span>
                  <p className="text-sm text-muted-foreground mt-1">Специалистов</p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-xl overflow-hidden shadow-2xl border border-border/50">
                <img  
                  className="w-full h-auto" 
                  alt="Команда DigitalCraft за работой"
                 src="https://images.unsplash.com/photo-1572177812156-58036aae439c" />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-card border border-border/50 rounded-xl p-4 shadow-xl max-w-xs">
                <p className="text-lg font-medium italic">
                  "Наша миссия — создавать цифровые решения, которые вдохновляют и приносят реальную пользу."
                </p>
                <p className="text-right text-primary mt-2">— Александр Иванов, CEO</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-20 bg-secondary/20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              className="text-primary text-sm font-medium uppercase tracking-wider"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Наши ценности
            </motion.span>
            <motion.h2
              className="text-3xl md:text-4xl font-bold mt-2 mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Принципы, которыми мы руководствуемся
            </motion.h2>
            <motion.p
              className="text-muted-foreground text-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Наши ценности определяют то, как мы работаем, принимаем решения и взаимодействуем с клиентами.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                className="service-card card-hover"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="mb-6">{value.icon}</div>
                <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              className="text-primary text-sm font-medium uppercase tracking-wider"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Наша команда
            </motion.span>
            <motion.h2
              className="text-3xl md:text-4xl font-bold mt-2 mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Познакомьтесь с профессионалами
            </motion.h2>
            <motion.p
              className="text-muted-foreground text-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Наша команда — это наша главная ценность. Каждый член команды вносит уникальный вклад в успех наших проектов.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-xl overflow-hidden card-hover"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="h-64 relative">
                  <img  
                    className="w-full h-full object-cover" 
                    alt={`${member.name}, ${member.position}`}
                   src="https://images.unsplash.com/photo-1524221629551-6dd14def5ffd" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold">{member.name}</h3>
                  <p className="text-primary mb-4">{member.position}</p>
                  <p className="text-muted-foreground">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Присоединяйтесь к нашим клиентам
            </motion.h2>
            <motion.p
              className="text-lg text-foreground/80 mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Давайте вместе создадим цифровое решение, которое поможет вашему бизнесу достичь новых высот.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button size="lg" className="px-8 py-6 text-lg">
                Связаться с нами
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
