
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Code, Palette, Smartphone, Globe, BarChart, Zap, CheckCircle } from "lucide-react";

const services = [
  {
    id: "web-development",
    icon: <Code className="h-12 w-12 text-primary" />,
    title: "Веб-разработка",
    description: "Создаем современные, быстрые и адаптивные веб-сайты с использованием передовых технологий.",
    features: [
      "Корпоративные сайты",
      "Интернет-магазины",
      "Лендинги",
      "Порталы и сервисы",
      "Прогрессивные веб-приложения (PWA)",
      "Интеграция с CRM и API"
    ],
    process: [
      "Анализ требований и бизнес-целей",
      "Прототипирование и дизайн",
      "Разработка и программирование",
      "Тестирование и отладка",
      "Запуск и поддержка"
    ]
  },
  {
    id: "ui-ux-design",
    icon: <Palette className="h-12 w-12 text-primary" />,
    title: "UI/UX Дизайн",
    description: "Разрабатываем интуитивно понятные интерфейсы, которые привлекают и удерживают пользователей.",
    features: [
      "Пользовательские исследования",
      "Прототипирование",
      "Дизайн интерфейсов",
      "Дизайн-системы",
      "Анимации и микровзаимодействия",
      "Юзабилити-тестирование"
    ],
    process: [
      "Исследование пользователей и конкурентов",
      "Создание пользовательских сценариев",
      "Разработка прототипов",
      "Дизайн интерфейса",
      "Тестирование и итерации"
    ]
  },
  {
    id: "mobile-development",
    icon: <Smartphone className="h-12 w-12 text-primary" />,
    title: "Мобильные приложения",
    description: "Создаем нативные и кроссплатформенные приложения для iOS и Android с современным дизайном.",
    features: [
      "Нативные приложения для iOS",
      "Нативные приложения для Android",
      "Кроссплатформенные приложения",
      "Интеграция с API и сервисами",
      "Push-уведомления",
      "Аналитика и мониторинг"
    ],
    process: [
      "Определение требований и функционала",
      "Проектирование архитектуры",
      "Дизайн интерфейса",
      "Разработка и тестирование",
      "Публикация в App Store и Google Play"
    ]
  },
  {
    id: "branding",
    icon: <Globe className="h-12 w-12 text-primary" />,
    title: "Брендинг",
    description: "Разрабатываем уникальную айдентику, которая выделит ваш бренд среди конкурентов.",
    features: [
      "Разработка логотипа",
      "Фирменный стиль",
      "Брендбук",
      "Упаковка и полиграфия",
      "Маркетинговые материалы",
      "Стратегия бренда"
    ],
    process: [
      "Анализ рынка и конкурентов",
      "Разработка концепции бренда",
      "Создание визуальной идентичности",
      "Подготовка брендбука",
      "Внедрение фирменного стиля"
    ]
  },
  {
    id: "seo",
    icon: <BarChart className="h-12 w-12 text-primary" />,
    title: "SEO-оптимизация",
    description: "Повышаем видимость вашего сайта в поисковых системах и увеличиваем органический трафик.",
    features: [
      "Технический аудит сайта",
      "Оптимизация контента",
      "Работа с ключевыми словами",
      "Внутренняя и внешняя оптимизация",
      "Локальное SEO",
      "Аналитика и отчетность"
    ],
    process: [
      "Аудит и анализ сайта",
      "Разработка SEO-стратегии",
      "Оптимизация контента и структуры",
      "Наращивание ссылочной массы",
      "Мониторинг и корректировка"
    ]
  },
  {
    id: "support",
    icon: <Zap className="h-12 w-12 text-primary" />,
    title: "Техническая поддержка",
    description: "Обеспечиваем бесперебойную работу вашего сайта и оперативно решаем возникающие проблемы.",
    features: [
      "Мониторинг работоспособности",
      "Обновление CMS и плагинов",
      "Резервное копирование",
      "Устранение ошибок",
      "Консультации и обучение",
      "Доработка функционала"
    ],
    process: [
      "Диагностика проблем",
      "Оперативное устранение неполадок",
      "Профилактические работы",
      "Обновление и оптимизация",
      "Консультирование клиентов"
    ]
  }
];

const faq = [
  {
    question: "Сколько времени занимает разработка сайта?",
    answer: "Сроки разработки зависят от сложности проекта. Лендинг может быть готов за 1-2 недели, корпоративный сайт за 3-4 недели, а интернет-магазин или сложный портал может занять 2-3 месяца. На первой консультации мы сможем дать более точную оценку по срокам."
  },
  {
    question: "Какова стоимость разработки?",
    answer: "Стоимость разработки индивидуальна для каждого проекта и зависит от его сложности, функционала и дизайна. Мы работаем по фиксированной цене, которая определяется после детального обсуждения требований. Свяжитесь с нами для получения коммерческого предложения."
  },
  {
    question: "Предоставляете ли вы техническую поддержку после запуска?",
    answer: "Да, мы предлагаем различные пакеты технической поддержки, которые включают мониторинг работоспособности, обновление CMS, резервное копирование, устранение ошибок и консультации. Вы можете выбрать подходящий пакет в зависимости от ваших потребностей."
  },
  {
    question: "Можете ли вы доработать существующий сайт?",
    answer: "Да, мы выполняем доработку и редизайн существующих сайтов. Сначала мы проводим аудит текущего состояния, а затем предлагаем решения по улучшению дизайна, функционала, скорости работы и SEO-оптимизации."
  },
  {
    question: "Как происходит процесс работы над проектом?",
    answer: "Наш процесс включает несколько этапов: анализ требований, прототипирование, дизайн, разработка, тестирование и запуск. На каждом этапе мы согласовываем результаты с клиентом и вносим необходимые корректировки. Мы используем гибкую методологию, которая позволяет адаптироваться к изменениям в процессе работы."
  }
];

const ServicesPage = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-background relative overflow-hidden hero-pattern">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600 blob" style={{ animationDuration: "15s" }}></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-600 blob" style={{ animationDuration: "20s" }}></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1
              className="text-4xl md:text-5xl font-bold mb-6 gradient-text"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Наши услуги
            </motion.h1>
            <motion.p
              className="text-xl text-muted-foreground mb-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Мы предлагаем полный спектр услуг по разработке и продвижению цифровых продуктов,
              которые помогут вашему бизнесу выйти на новый уровень.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              id={service.id}
              className="mb-24 last:mb-0"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className={`order-2 ${index % 2 === 0 ? 'lg:order-2' : 'lg:order-1'}`}>
                  <div className="relative rounded-xl overflow-hidden shadow-2xl border border-border/50">
                    <img  
                      className="w-full h-auto" 
                      alt={`Услуга ${service.title}`}
                     src="https://images.unsplash.com/photo-1524221629551-6dd14def5ffd" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
                  </div>
                </div>
                
                <div className={`order-1 ${index % 2 === 0 ? 'lg:order-1' : 'lg:order-2'}`}>
                  <div className="flex items-center mb-4">
                    {service.icon}
                    <h2 className="text-3xl font-bold ml-4">{service.title}</h2>
                  </div>
                  
                  <p className="text-lg text-muted-foreground mb-8">
                    {service.description}
                  </p>
                  
                  <h3 className="text-xl font-semibold mb-4">Что мы предлагаем:</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <h3 className="text-xl font-semibold mb-4">Наш процесс:</h3>
                  <ol className="space-y-3 mb-8">
                    {service.process.map((step, i) => (
                      <li key={i} className="flex items-start">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm font-medium mr-3 shrink-0">
                          {i + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                  
                  <Button size="lg" className="mt-4">
                    Заказать услугу
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-secondary/20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              className="text-primary text-sm font-medium uppercase tracking-wider"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Часто задаваемые вопросы
            </motion.span>
            <motion.h2
              className="text-3xl md:text-4xl font-bold mt-2 mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Ответы на популярные вопросы
            </motion.h2>
          </div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
              {faq.map((item, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-lg font-medium">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Готовы обсудить ваш проект?
            </motion.h2>
            <motion.p
              className="text-lg text-foreground/80 mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Свяжитесь с нами сегодня, чтобы получить бесплатную консультацию и узнать,
              как мы можем помочь вашему бизнесу.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button size="lg" className="px-8 py-6 text-lg">
                Связаться с нами
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;
