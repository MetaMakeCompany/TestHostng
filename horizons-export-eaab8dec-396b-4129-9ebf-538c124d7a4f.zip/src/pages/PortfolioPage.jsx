
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

const categories = [
  "Все",
  "Веб-разработка",
  "Мобильные приложения",
  "UI/UX Дизайн",
  "Брендинг",
  "E-commerce"
];

const portfolioItems = [
  {
    id: 1,
    title: "Корпоративный сайт для IT-компании",
    category: "Веб-разработка",
    description: "Современный корпоративный сайт с адаптивным дизайном и интерактивными элементами. Разработан для IT-компании, специализирующейся на облачных решениях.",
    technologies: ["React", "Node.js", "MongoDB", "Tailwind CSS"],
    results: ["Увеличение конверсии на 35%", "Снижение отказов на 25%", "Рост органического трафика на 40%"]
  },
  {
    id: 2,
    title: "Мобильное приложение для фитнеса",
    category: "Мобильные приложения",
    description: "Приложение для отслеживания тренировок с персонализированными программами и аналитикой. Включает интеграцию с фитнес-трекерами и социальными сетями.",
    technologies: ["React Native", "Firebase", "Redux", "Google Fit API"],
    results: ["100,000+ загрузок", "Рейтинг 4.8/5 в App Store", "Удержание пользователей 65%"]
  },
  {
    id: 3,
    title: "Интернет-магазин электроники",
    category: "E-commerce",
    description: "Полнофункциональный интернет-магазин с интеграцией платежных систем и CRM. Реализована система фильтрации, сравнения товаров и персональных рекомендаций.",
    technologies: ["Vue.js", "Laravel", "MySQL", "Stripe"],
    results: ["Рост продаж на 75%", "Увеличение среднего чека на 30%", "Сокращение времени загрузки на 60%"]
  },
  {
    id: 4,
    title: "Редизайн бренда косметической компании",
    category: "Брендинг",
    description: "Комплексный ребрендинг, включающий логотип, упаковку и маркетинговые материалы. Создание единой визуальной идентичности для линейки из 30+ продуктов.",
    technologies: ["Adobe Creative Suite", "Figma", "Принципы устойчивого дизайна"],
    results: ["Узнаваемость бренда выросла на 45%", "Увеличение продаж на 28%", "Расширение целевой аудитории"]
  },
  {
    id: 5,
    title: "Лендинг для образовательного курса",
    category: "Веб-разработка",
    description: "Высококонверсионный лендинг с анимациями и интерактивными элементами. Интеграция с системой оплаты и CRM для автоматизации процесса регистрации.",
    technologies: ["HTML5", "CSS3", "JavaScript", "GSAP"],
    results: ["Конверсия 12.5%", "ROI 320%", "Снижение стоимости привлечения клиента на 40%"]
  },
  {
    id: 6,
    title: "Дашборд для аналитической платформы",
    category: "UI/UX Дизайн",
    description: "Интуитивно понятный интерфейс для визуализации и анализа больших данных. Разработка пользовательских сценариев и интерактивных прототипов.",
    technologies: ["Figma", "Sketch", "Principle", "D3.js"],
    results: ["Сокращение времени на анализ данных на 65%", "Повышение удовлетворенности пользователей на 48%"]
  },
  {
    id: 7,
    title: "Приложение для доставки еды",
    category: "Мобильные приложения",
    description: "Мобильное приложение для заказа и доставки еды из ресторанов. Реализована система отслеживания заказа в реальном времени и программа лояльности.",
    technologies: ["Flutter", "Firebase", "Google Maps API", "Stripe"],
    results: ["50,000+ активных пользователей", "Средний рейтинг 4.7/5", "Рост заказов на 85%"]
  },
  {
    id: 8,
    title: "Онлайн-платформа для обучения",
    category: "Веб-разработка",
    description: "Образовательная платформа с системой управления курсами, видеоконференциями и аналитикой прогресса обучения.",
    technologies: ["React", "Node.js", "MongoDB", "WebRTC"],
    results: ["10,000+ зарегистрированных студентов", "Завершаемость курсов 78%", "Рост выручки на 120%"]
  },
  {
    id: 9,
    title: "Фирменный стиль для стартапа",
    category: "Брендинг",
    description: "Разработка логотипа, фирменного стиля и брендбука для технологического стартапа. Создание визуальной коммуникации для различных каналов.",
    technologies: ["Adobe Illustrator", "Adobe Photoshop", "Figma"],
    results: ["Успешное привлечение инвестиций", "Повышение узнаваемости бренда на 60%"]
  }
];

const PortfolioPage = () => {
  const [activeCategory, setActiveCategory] = useState("Все");
  const [selectedProject, setSelectedProject] = useState(null);

  const filteredProjects = activeCategory === "Все"
    ? portfolioItems
    : portfolioItems.filter(item => item.category === activeCategory);

  const handleCategoryChange = (category) => {
    setActiveCategory(category);
  };

  const handleProjectClick = (project) => {
    setSelectedProject(project);
  };

  const closeProjectDetails = () => {
    setSelectedProject(null);
  };

  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-background relative overflow-hidden hero-pattern">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600 blob" style={{ animationDuration: "15s" }}></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-600 blob" style={{ animationDuration: "20s" }}></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1
              className="text-4xl md:text-5xl font-bold mb-6 gradient-text"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Наше портфолио
            </motion.h1>
            <motion.p
              className="text-xl text-muted-foreground mb-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Ознакомьтесь с нашими проектами, которые демонстрируют наш подход
              к созданию эффективных цифровых решений.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {categories.map((category, index) => (
              <Button
                key={index}
                variant={activeCategory === category ? "default" : "outline"}
                onClick={() => handleCategoryChange(category)}
                className="mb-2"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Projects Grid */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                className="portfolio-item card-hover cursor-pointer"
                onClick={() => handleProjectClick(project)}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                whileHover={{ y: -10, transition: { duration: 0.2 } }}
              >
                <img  
                  className="w-full h-64 object-cover rounded-xl" 
                  alt={project.title}
                 src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                
                <div className="portfolio-item-overlay rounded-xl">
                  <span className="text-primary text-sm font-medium uppercase tracking-wider mb-2">
                    {project.category}
                  </span>
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {project.description}
                  </p>
                  <Button size="sm" className="group">
                    Подробнее
                    <ExternalLink className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Project Details Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            className="bg-card border border-border rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="relative">
              <button
                onClick={closeProjectDetails}
                className="absolute top-4 right-4 bg-background/50 backdrop-blur-sm rounded-full p-2 text-foreground hover:bg-background/80 transition-colors z-10"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 6 6 18"></path>
                  <path d="m6 6 12 12"></path>
                </svg>
              </button>
              
              <div className="relative h-64 md:h-80">
                <img  
                  className="w-full h-full object-cover rounded-t-xl" 
                  alt={selectedProject.title}
                 src="https://images.unsplash.com/photo-1613275300115-0aa869c107e0" />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <span className="text-primary text-sm font-medium uppercase tracking-wider mb-2 block">
                    {selectedProject.category}
                  </span>
                  <h2 className="text-2xl md:text-3xl font-bold">{selectedProject.title}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">О проекте</h3>
                <p className="text-muted-foreground mb-6">{selectedProject.description}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Технологии</h3>
                    <ul className="space-y-2">
                      {selectedProject.technologies.map((tech, index) => (
                        <li key={index} className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2">
                            <polyline points="9 11 12 14 22 4"></polyline>
                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                          </svg>
                          {tech}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Результаты</h3>
                    <ul className="space-y-2">
                      {selectedProject.results.map((result, index) => (
                        <li key={index} className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2">
                            <path d="m5 12 5 5L20 7"></path>
                          </svg>
                          {result}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button onClick={closeProjectDetails}>Закрыть</Button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Готовы создать ваш проект?
            </motion.h2>
            <motion.p
              className="text-lg text-foreground/80 mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Давайте обсудим, как мы можем помочь вашему бизнесу с помощью
              инновационных цифровых решений.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button size="lg" className="px-8 py-6 text-lg">
                Связаться с нами
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PortfolioPage;
