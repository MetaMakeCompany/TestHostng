
import React from "react";
import { motion } from "framer-motion";
import { Code, Palette, Smartphone, Globe, BarChart, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: <Code className="h-10 w-10 text-primary" />,
    title: "Веб-разработка",
    description: "Создаем современные, быстрые и адаптивные веб-сайты с использованием передовых технологий.",
  },
  {
    icon: <Palette className="h-10 w-10 text-primary" />,
    title: "UI/UX Дизайн",
    description: "Разрабатываем интуитивно понятные интерфейсы, которые привлекают и удерживают пользователей.",
  },
  {
    icon: <Smartphone className="h-10 w-10 text-primary" />,
    title: "Мобильные приложения",
    description: "Создаем нативные и кроссплатформенные приложения для iOS и Android с современным дизайном.",
  },
  {
    icon: <Globe className="h-10 w-10 text-primary" />,
    title: "Брендинг",
    description: "Разрабатываем уникальную айдентику, которая выделит ваш бренд среди конкурентов.",
  },
  {
    icon: <BarChart className="h-10 w-10 text-primary" />,
    title: "SEO-оптимизация",
    description: "Повышаем видимость вашего сайта в поисковых системах и увеличиваем органический трафик.",
  },
  {
    icon: <Zap className="h-10 w-10 text-primary" />,
    title: "Техническая поддержка",
    description: "Обеспечиваем бесперебойную работу вашего сайта и оперативно решаем возникающие проблемы.",
  },
];

const ServicesSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 md:py-32 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            className="text-primary text-sm font-medium uppercase tracking-wider"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Наши услуги
          </motion.span>
          <motion.h2
            className="text-3xl md:text-4xl font-bold mt-2 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Комплексные решения для вашего бизнеса
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Мы предлагаем полный спектр услуг по разработке и продвижению цифровых продуктов,
            которые помогут вашему бизнесу выйти на новый уровень.
          </motion.p>
        </div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="service-card card-hover"
              variants={itemVariants}
            >
              <div className="mb-6">{service.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
              <p className="text-muted-foreground mb-6">{service.description}</p>
              <Button variant="ghost" className="group">
                Подробнее
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1"
                >
                  <path d="M5 12h14"></path>
                  <path d="m12 5 7 7-7 7"></path>
                </svg>
              </Button>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-16">
          <Button size="lg" className="px-8">
            Все услуги
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
