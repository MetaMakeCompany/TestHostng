
import React from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Алексей Петров",
    position: "CEO, TechInnovate",
    content: "Сотрудничество с DigitalCraft превзошло все наши ожидания. Команда профессионалов создала для нас не просто сайт, а эффективный инструмент для привлечения клиентов. Рекомендую!",
    rating: 5,
  },
  {
    name: "Елена Смирнова",
    position: "Маркетинг-директор, FashionBrand",
    content: "Благодаря редизайну нашего сайта и внедрению новой стратегии SEO, наш трафик вырос на 150% за 3 месяца. Команда DigitalCraft всегда на связи и оперативно реагирует на все запросы.",
    rating: 5,
  },
  {
    name: "Дмитрий Иванов",
    position: "Основатель, EduTech",
    content: "Мобильное приложение, разработанное DigitalCraft, получило отличные отзывы от пользователей. Особенно ценю внимание к деталям и готовность команды внедрять наши идеи.",
    rating: 4,
  },
];

const TestimonialsSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 md:py-32 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            className="text-primary text-sm font-medium uppercase tracking-wider"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Отзывы
          </motion.span>
          <motion.h2
            className="text-3xl md:text-4xl font-bold mt-2 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Что говорят наши клиенты
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Мы гордимся отзывами наших клиентов и стремимся превосходить их ожидания
            в каждом проекте.
          </motion.p>
        </div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              className="testimonial-card card-hover"
              variants={itemVariants}
            >
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < testimonial.rating
                        ? "text-yellow-500 fill-yellow-500"
                        : "text-muted-foreground"
                    }`}
                  />
                ))}
              </div>
              <p className="text-foreground mb-6">{testimonial.content}</p>
              <div className="flex items-center">
                <div className="rounded-full overflow-hidden mr-4">
                  <img  
                    className="h-12 w-12 object-cover" 
                    alt={`Фото ${testimonial.name}`}
                   src="https://images.unsplash.com/photo-1606121537863-3fdbe9f3e42a" />
                </div>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.position}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
