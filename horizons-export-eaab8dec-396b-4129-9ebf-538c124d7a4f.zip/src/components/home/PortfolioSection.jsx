
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

const portfolioItems = [
  {
    title: "Корпоративный сайт для IT-компании",
    category: "Веб-разработка",
    description: "Современный корпоративный сайт с адаптивным дизайном и интерактивными элементами.",
  },
  {
    title: "Мобильное приложение для фитнеса",
    category: "Мобильная разработка",
    description: "Приложение для отслеживания тренировок с персонализированными программами и аналитикой.",
  },
  {
    title: "Интернет-магазин электроники",
    category: "E-commerce",
    description: "Полнофункциональный интернет-магазин с интеграцией платежных систем и CRM.",
  },
  {
    title: "Редизайн бренда косметической компании",
    category: "Брендинг",
    description: "Комплексный ребрендинг, включающий логотип, упаковку и маркетинговые материалы.",
  },
  {
    title: "Лендинг для образовательного курса",
    category: "Веб-дизайн",
    description: "Высококонверсионный лендинг с анимациями и интерактивными элементами.",
  },
  {
    title: "Дашборд для аналитической платформы",
    category: "UI/UX Дизайн",
    description: "Интуитивно понятный интерфейс для визуализации и анализа больших данных.",
  },
];

const PortfolioSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 md:py-32 bg-secondary/20 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            className="text-primary text-sm font-medium uppercase tracking-wider"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Наши работы
          </motion.span>
          <motion.h2
            className="text-3xl md:text-4xl font-bold mt-2 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Последние проекты
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Ознакомьтесь с нашими последними работами, которые демонстрируют наш подход
            к созданию эффективных цифровых решений.
          </motion.p>
        </div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {portfolioItems.map((item, index) => (
            <motion.div
              key={index}
              className="portfolio-item card-hover"
              variants={itemVariants}
            >
              <img  
                className="w-full h-64 object-cover rounded-xl" 
                alt={item.title}
               src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
              
              <div className="portfolio-item-overlay rounded-xl">
                <span className="text-primary text-sm font-medium uppercase tracking-wider mb-2">
                  {item.category}
                </span>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {item.description}
                </p>
                <Button size="sm" className="group">
                  Подробнее
                  <ExternalLink className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-16">
          <Button size="lg" variant="outline" className="px-8">
            Смотреть все проекты
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
